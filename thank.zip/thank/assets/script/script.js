let matrix=[
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    [0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];
// Load the level.json
let get_container=document.querySelector('.container');
const block=1,vide=0;
let pos=[];
class TanklInterface{
    interfaceState(){
        matrix.forEach((el,index)=>{
            el.forEach((ele,Index)=>{
                let blockEle=document.createElement('div');
                switch (ele) {
                    case 0:/*vide*/
                        get_container.appendChild(blockEle);
                    break;
                    case 1:/*mur gris*/
                        blockEle.classList.add('block');
                        get_container.appendChild(blockEle);
                    break;
                    case 2:/*mur gris*/
                        blockEle.classList.add('block');
                        get_container.appendChild(blockEle);
                    break;
                    default:
                    break;
                }
            })
        })
    }   
    NewState(){
        while (get_container.firstChild) {
            get_container.firstChild.remove();
        }
    }
}
class Play{
    constructor(direction,pos,interFace,attack){
        this.direction=direction;
        this.pos=pos;
        this.interFace=interFace;
        this.attack=attack;
    }
    GetPosTank(){
        this.pos=[];
        for (let i = 0; i < matrix.length; i++) {
            const element = matrix[i];
            for (let j = 0; j < element.length; j++) {
                const val = element[j];
                if(val==2){
                    var temp=[];
                    temp.push(i);
                    temp.push(j);
                    this.pos.push(temp);
                }                
            }
        }
        return this.pos;
    }
    Move(){
    let pos=this.GetPosTank(),posRDY=pos[6][1],posRUY=pos[3][1],posLDY=pos[4][1],posLUY=pos[1][1];
    let posRDX=pos[6][0],posRUX=pos[3][0],posLDX=pos[4][0],posLUX=pos[1][0]; 
    let posMX=pos[0][0],posMY=pos[0][1];   
        switch(this.direction){
            case"ArrowRight":
                if( (posRUX-1>=0 && posRUX<matrix[0].length) && (posMY-1>-1 && posMY+1<matrix[0].length) ){
                    this.attack.BeginAttack(posMX,posMY);
                   [matrix[posLDX][posLDY],matrix[posLDX][posLDY+3]]=[matrix[posLDX][posLDY+3],matrix[posLDX][posLDY]];
                   [matrix[posLUX][posLUY],matrix[posLUX][posLUY+3]]=[matrix[posLUX][posLUY+3],matrix[posLUX][posLUY]];
                   [matrix[posMX][posMY],matrix[posMX][posMY+1]]=[matrix[posMX][posMY+1],matrix[posMX][posMY]];
                   this.interFace.NewState();
                   this.interFace.interfaceState();
                }
            break;
            case"ArrowLeft":
            if( (posMY-1>=0 && posMY+1<matrix[0].length) ){
                this.attack.BeginAttack(posMX,posMY);
                [matrix[posRDX][posRDY],matrix[posRDX][posRDY-3]]=[matrix[posRDX][posRDY-3],matrix[posRDX][posRDY]];
                [matrix[posRUX][posRUY],matrix[posRUX][posRUY-3]]=[matrix[posRUX][posRUY-3],matrix[posRUX][posRUY]];
                [matrix[posMX][posMY],matrix[posMX][posMY-1]]=[matrix[posMX][posMY-1],matrix[posMX][posMY]];
                this.interFace.NewState();
                this.interFace.interfaceState();
             }
            break;
        }
    }
}
class Atttack{
    BeginAttack(X,Y){
    let PsX=X;
        while(matrix[PsX][Y]!=1){
            PsX--;
        }
        matrix[PsX][Y]=vide;
        return PsX;
    }
}
let interface = new TanklInterface(),attack=new Atttack();
interface.interfaceState();
let direction=["ArrowLeft","ArrowRight"];
setInterval(function(){
    let dir=direction[Math.floor(Math.random() * (2-0)) + 0];
    let play=new Play(dir,pos,interface,attack);
    play.Move();
},1000);